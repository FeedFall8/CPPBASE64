#include<iostream>
#include<fstream>
#include<windows.h>
#include<stdlib.h>
#include <stdio.h>
using namespace std;
char* string_as_array(string* str)
{
	return str->empty() ? NULL : &*str->begin();
}
class base64 {
public:
	string encode(string text)
	{
		string command = "scripts\\encoder\\encoder.exe " + text;
		//cout << command;
		char* cmd = string_as_array(&command);
		// text;
		system(cmd);

		/*system(command);
		ifstream data;
		data.open(".b64e");*/
		ifstream data;
		data.open(".b64e");
		string l;
		for (string line; getline(data, line);) {
			l = line;
		}
		remove(".b64e");
		return l;

		

	}
	string decode(string text)
	{
		string command = "scripts\\decoder\\decoder.exe " + text;
		//cout << command;
		char* cmd = string_as_array(&command);
		// text;
		system(cmd);

		/*system(command);
		ifstream data;
		data.open(".b64e");*/
		ifstream data;
		data.open(".b64d");
		string l;
		for (string line; getline(data, line);) {
			l = line;
		}
		remove(".b64d");
		return l;



	}
	
};
