#include<iostream>
#include"Base64.h"

using namespace std;
int main() {
	base64 b64;
	string str="HELLO WORLD";
	cout << b64.encode(str) << endl;
	str = b64.encode(str);
	cout << b64.decode(str) << endl;
}